[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/AutoAutoAI/Curriculum/master)

# Data Science Curriculum  
This is the repo for some of the data science related curriculum AutoAuto offers using Jupyter notebooks.


 __Contact__:`contact@autauto.ai`



[-----------------------------LINKS-----------------------------]: #


[auto-auto-website]:http://autoauto.ai/
